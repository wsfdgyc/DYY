-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[更新影票状态]

AS
BEGIN
insert Tickets
(
	   [FileName] 
	  ,[ListingID]
	  ,[FilmID]
	  ,[HallID]
      ,[Date]
      ,[StartTime]
      ,[EndTime]
	  ,[Rows]
	  ,[Columns]
      ,[RowID]
      ,[ColumnID]
      ,[Price]
      ,[SellStatus]	
)
SELECT  c.FilmName
	  ,a.ListingID
	  ,a.FilmID
      ,[HallID]
      ,[Date]
      ,[StratTime]
      ,[EndTime]
	  ,b.rows
	  ,b.columns
	  ,b.rowid
	  ,b.columnid	  
      ,[Price]
	  ,'0' as SellStatus
  FROM [DYY].[dbo].[FilmListing] a
  left join Cinema b
  on a.HallID=b.VideoHallID
  left join Film c
  on a.FilmID=c.FilmID
  where a.finishStatus='0'
  order by date,ListingID,b.rowid,b.columnid
  ;
  update FilmListing
  set finishStatus='1'
  where FinishStatus='0'
END
GO
