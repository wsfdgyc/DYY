CREATE VIEW dbo.ViewFilmListing
AS
SELECT   b.FilmName, a.ListingID, a.HallID, a.Date, a.Number, a.FilmID, a.StratTime, a.EndTime, a.Price
FROM      dbo.FilmListing AS a LEFT OUTER JOIN
                dbo.Film AS b ON a.FilmID = b.FilmID
GO
