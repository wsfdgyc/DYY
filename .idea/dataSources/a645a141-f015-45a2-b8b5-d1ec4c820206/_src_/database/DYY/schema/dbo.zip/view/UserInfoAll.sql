CREATE VIEW dbo.UserInfoAll
AS
SELECT   dbo.UserInfo.UserName, dbo.UserInfo.Pwd, dbo.UserInfo.Status, dbo.UserInfo.Power, dbo.UserBal.Bal
FROM      dbo.UserInfo INNER JOIN
                dbo.UserBal ON dbo.UserInfo.UserName = dbo.UserBal.UserName
GO
